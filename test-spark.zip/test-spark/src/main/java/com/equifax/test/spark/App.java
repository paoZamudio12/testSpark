package com.equifax.test.spark;

import org.apache.log4j.Logger;

import com.equifax.test.spark.reports.ReportGenerator;

/**
 * Main class
 *
 */
public class App {
	
   static Logger logger = Logger.getLogger(App.class);
	
	
	public static void main(String[] arg) throws Exception {
	
		logger.info("App test application starting... ");
		
		try {
			 ReportGenerator generator = new ReportGenerator();
			 generator.getAccountsData();
			 generator.getReportTwo();
			
			  logger.info("App test application finished.");
			  
		}catch (Exception e) {
			logger.error(e.getMessage());
		}
	}
}
