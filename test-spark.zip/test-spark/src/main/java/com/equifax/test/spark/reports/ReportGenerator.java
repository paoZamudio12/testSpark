/**
 * 
 */
package com.equifax.test.spark.reports;

import java.io.BufferedWriter;
import java.nio.charset.Charset;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.log4j.Logger;
import org.apache.spark.SparkConf;
import org.apache.spark.SparkContext;
import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.RelationalGroupedDataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.*;
import org.apache.spark.sql.expressions.Window;
import org.apache.spark.sql.expressions.WindowSpec;


/**
 * @author Paola
 *
 */
public class ReportGenerator {
	
	static Logger logger = Logger.getLogger(ReportGenerator.class);
	
	private static final SparkConf conf = new SparkConf().setAppName("SparkTest").setMaster("local");
	
	private static final SparkContext context = new SparkContext(conf);
	
	// create spark Session
	private static SparkSession sparkSession = new SparkSession(context);
	
	private String accountFile="C:\\Test\\resources\\accounts.csv";
	private String customerFile="C:\\Test\\resources\\customer.json";
	
	
	public ReportGenerator() {
		// TODO Auto-generated constructor stub
	}

	public void getAccountsData() throws Exception{
		logger.info("getAccountsData starting... ");
		
		List<Row> listCount;
		List<Row> listDesc;
		StringBuilder strCont = new  StringBuilder();
		StringBuilder strAccounts = new  StringBuilder();
		List<String> listContent = new ArrayList<>(); 
		String client=null;
		String namefile= "C:\\Test\\reports\\report1.txt";
		
		try {
			Dataset<Row> df = sparkSession.read().format("com.databricks.spark.csv")
												.option("header", true).option("inferSchema", true)
												.load(accountFile);
			df.show();
	
			Dataset<Row> dfCustomer = sparkSession.read().json(customerFile);
			dfCustomer.show();
			
			Dataset<Row> dCount = df.select("account","client").join(dfCustomer.select("client","name"), "client")
																.groupBy("client","name").count();
			dCount.show();
			
			Dataset<Row> dDescrip = df.select("account","client");
			dDescrip.show();
			
			long countData = dCount.count();
			if( dCount!=null && dDescrip!=null ) {
				if( countData>0 ){
					listCount = dCount.collectAsList();
					listDesc = dDescrip.collectAsList();
					
					if( listCount!=null && !listCount.isEmpty() && listCount.size()>0 ){
						Iterator<Row> iter = listCount.iterator();
						
						while( iter.hasNext() ) {
						  Row rowObj = (Row)iter.next();
						  int totCount=0;

			              strCont = new  StringBuilder();
		            	  strCont.append( rowObj.get(1).toString() +",");
		            	  totCount = new Integer(rowObj.get(2).toString()).intValue();
		            	  strCont.append( " total accounts: "+rowObj.get(2).toString() +"," );
		            	  
		            	  client=rowObj.get(0).toString();
		            	   
		            	  logger.info( "client 1::"+client );
		            	  
		            	  if( listDesc!=null && !listDesc.isEmpty() && listDesc.size()>0 ){
								Iterator<Row> iterDesc = listDesc.iterator();
								int numCount=1;
								
								while( iterDesc.hasNext() ) {
								Row rowAccount = (Row)iterDesc.next();
								strAccounts = new  StringBuilder();
								
								if( rowAccount.get(1).toString().equals(client) ) {
									logger.info( "client 2::" +rowAccount.get(1).toString() );
									
									strAccounts.append(" account"+numCount+": ");
									strAccounts.append( rowAccount.get(0).toString() );
									if(totCount!=numCount) {
									   strAccounts.append( "," );
									}
									numCount++;
								}	
								strCont.append(strAccounts);
							}
		            	  }
		            	  listContent.add( strCont.toString() );
						}
						logger.info("listContent.size()::" +listContent.size() );
						logger.info( listContent.toString() );
					}
				}
			}
			
			viewContentReport(listContent );
			createReportFile(listContent, namefile);
		}catch (Exception e) {
			logger.error(e.getMessage());
		}finally {
			//sparkSession.close();
		}
	}
		
		
		public void getReportTwo() throws Exception{
			logger.info("getReportTwo starting... ");
			
			List<Row> listCount;
			List<Row> listDesc;
			StringBuilder strCont = new  StringBuilder();
			StringBuilder strAccounts = new  StringBuilder();
			List<String> listContent = new ArrayList<>(); 
			String client=null;
			String clientAux="";
			String namefile= "C:\\Test\\reports\\report2.txt";
			
			try {
				Dataset<Row> df = sparkSession.read().format("com.databricks.spark.csv")
													.option("header", true).option("inferSchema", true)
													.load(accountFile);
				df.show();
		
				Dataset<Row> dfCustomer = sparkSession.read().json(customerFile);
				dfCustomer.show();
			
				Dataset<Row> dCount = df.select("group","client","amount")
																	.groupBy("client","group").sum("amount").orderBy("client")
																	.withColumn("name_group",functions$.MODULE$.when( df.col("group").$eq$eq$eq(1), "Mortgage")
																												.when( df.col("group").$eq$eq$eq(6), "Credit Card")
																												.when( df.col("group").$eq$eq$eq(8), "Personal Loan"));
																	
				dCount.show();
				
				Dataset<Row> dDescrip = dfCustomer.select("name","client");
				dDescrip.show();
				
				long countData = dCount.count();
				
				
				if( dCount!=null ) {
					if( countData>0 ){
						listCount = dCount.collectAsList();
						listDesc = dDescrip.collectAsList();
						
						if( listDesc!=null && !listDesc.isEmpty() && listDesc.size()>0 ){
							Iterator<Row> iter = listDesc.iterator();
							
							while( iter.hasNext() ) {
							  Row rowObj = (Row)iter.next();
							  client = rowObj.get(1).toString();
							  strCont = new  StringBuilder();
							  
							  logger.info( "client 1::"+client );
							  strCont.append( rowObj.get(0).toString() +", ");
							  
							  if( listCount!=null && !listCount.isEmpty() && listCount.size()>0 ){
									Iterator<Row> iterDesc = listCount.iterator();
									strAccounts = new  StringBuilder();
									
									while( iterDesc.hasNext() ) {
										Row rowAccount = (Row)iterDesc.next();
										clientAux = rowAccount.get(0).toString();
										
										logger.info( "client 2::" +clientAux );
										
										if( clientAux.equals(client) ) {
											strAccounts.append( rowAccount.get(3).toString() +": ");
											strAccounts.append( new Double(rowAccount.get(2).toString()) +"," );
											logger.info( "client 2 strAccounts::" +strAccounts );
										}	
									}
			            	  }
							  
							  strCont.append(strAccounts);
			            	  listContent.add( strCont.toString() );
							}
							logger.info("listContent.size()::" +listContent.size() );
							logger.info( listContent.toString() );
						}
					}
				}
				viewContentReport(listContent );
				createReportFile(listContent, namefile);
			}catch (Exception e) {
				logger.error(e.getMessage());
			}finally {
				//sparkSession.close();
			}
		
	}

	
	public void viewContentReport(List<String> listContent ) {
		Iterator iterB = listContent.iterator();
		
		logger.info( "Report Content::");
		while( iterB.hasNext() ) {
			logger.info( iterB.next().toString() );
		}
	}
	
	public void createReportFile(List<String> listContent, String namefile) {
	
		if( listContent!=null && !listContent.isEmpty() ) {
		    Path path = Paths.get(namefile);
		    logger.info( "Create file...");
		    
		      try (BufferedWriter br = Files.newBufferedWriter(path,
		            Charset.defaultCharset(), StandardOpenOption.CREATE)) {
		    	    Iterator<String> iterB = listContent.iterator();
		  		
			  		logger.info( "Report Content::");
			  		while( iterB.hasNext() ) {
			  			 br.write(iterB.next().toString());
				         br.newLine();
			  		}   
		      } catch (Exception e) {
		         e.printStackTrace();
		      }
			}
		}

}
